﻿namespace MainApp.ChildForms
{
    partial class Materias
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelTEMPORAL = new System.Windows.Forms.Panel();
            this.pnlBotonesMaterias = new System.Windows.Forms.Panel();
            this.pnlAgregar = new System.Windows.Forms.Panel();
            this.tlpAgregarCC = new System.Windows.Forms.TableLayoutPanel();
            this.btnAgregarConf = new FontAwesome.Sharp.IconButton();
            this.btnAgregarCanc = new FontAwesome.Sharp.IconButton();
            this.lblAgColor = new System.Windows.Forms.Label();
            this.txtAgregar = new System.Windows.Forms.TextBox();
            this.lblAgNombre = new System.Windows.Forms.Label();
            this.btnAgregarColor = new FontAwesome.Sharp.IconButton();
            this.pnlEliminar = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.btnEliminarConf = new FontAwesome.Sharp.IconButton();
            this.btnEliminarCanc = new FontAwesome.Sharp.IconButton();
            this.txtEliminar = new System.Windows.Forms.TextBox();
            this.lblElNombre = new System.Windows.Forms.Label();
            this.pnlEditar = new System.Windows.Forms.Panel();
            this.tlpEditar = new System.Windows.Forms.TableLayoutPanel();
            this.pnlEdMateria = new System.Windows.Forms.Panel();
            this.lblEdMateria = new System.Windows.Forms.Label();
            this.txtEdMateria = new System.Windows.Forms.TextBox();
            this.pnlEdNuevo = new System.Windows.Forms.Panel();
            this.lblEdNuevo = new System.Windows.Forms.Label();
            this.txtEdNuevo = new System.Windows.Forms.TextBox();
            this.tlpEditarCC = new System.Windows.Forms.TableLayoutPanel();
            this.btnEditarConf = new FontAwesome.Sharp.IconButton();
            this.btnEditarCanc = new FontAwesome.Sharp.IconButton();
            this.lblEdColor = new System.Windows.Forms.Label();
            this.btnEditarColor = new FontAwesome.Sharp.IconButton();
            this.lblWarning = new System.Windows.Forms.Label();
            this.tlpBotonesMaterias = new System.Windows.Forms.TableLayoutPanel();
            this.btnAgregar = new FontAwesome.Sharp.IconButton();
            this.btnEliminar = new FontAwesome.Sharp.IconButton();
            this.btnEditar = new FontAwesome.Sharp.IconButton();
            this.pnlMaterias = new System.Windows.Forms.Panel();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.pnlBotonesMaterias.SuspendLayout();
            this.pnlAgregar.SuspendLayout();
            this.tlpAgregarCC.SuspendLayout();
            this.pnlEliminar.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.pnlEditar.SuspendLayout();
            this.tlpEditar.SuspendLayout();
            this.pnlEdMateria.SuspendLayout();
            this.pnlEdNuevo.SuspendLayout();
            this.tlpEditarCC.SuspendLayout();
            this.tlpBotonesMaterias.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelTEMPORAL
            // 
            this.panelTEMPORAL.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelTEMPORAL.Location = new System.Drawing.Point(0, 430);
            this.panelTEMPORAL.Margin = new System.Windows.Forms.Padding(0);
            this.panelTEMPORAL.Name = "panelTEMPORAL";
            this.panelTEMPORAL.Size = new System.Drawing.Size(800, 20);
            this.panelTEMPORAL.TabIndex = 0;
            // 
            // pnlBotonesMaterias
            // 
            this.pnlBotonesMaterias.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlBotonesMaterias.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.pnlBotonesMaterias.Controls.Add(this.pnlAgregar);
            this.pnlBotonesMaterias.Controls.Add(this.pnlEliminar);
            this.pnlBotonesMaterias.Controls.Add(this.pnlEditar);
            this.pnlBotonesMaterias.Controls.Add(this.lblWarning);
            this.pnlBotonesMaterias.Controls.Add(this.tlpBotonesMaterias);
            this.pnlBotonesMaterias.Location = new System.Drawing.Point(20, 20);
            this.pnlBotonesMaterias.Margin = new System.Windows.Forms.Padding(0);
            this.pnlBotonesMaterias.MinimumSize = new System.Drawing.Size(0, 42);
            this.pnlBotonesMaterias.Name = "pnlBotonesMaterias";
            this.pnlBotonesMaterias.Size = new System.Drawing.Size(760, 389);
            this.pnlBotonesMaterias.TabIndex = 1;
            // 
            // pnlAgregar
            // 
            this.pnlAgregar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlAgregar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.pnlAgregar.Controls.Add(this.tlpAgregarCC);
            this.pnlAgregar.Controls.Add(this.lblAgColor);
            this.pnlAgregar.Controls.Add(this.txtAgregar);
            this.pnlAgregar.Controls.Add(this.lblAgNombre);
            this.pnlAgregar.Controls.Add(this.btnAgregarColor);
            this.pnlAgregar.Location = new System.Drawing.Point(0, 42);
            this.pnlAgregar.Margin = new System.Windows.Forms.Padding(0);
            this.pnlAgregar.Name = "pnlAgregar";
            this.pnlAgregar.Size = new System.Drawing.Size(760, 86);
            this.pnlAgregar.TabIndex = 4;
            // 
            // tlpAgregarCC
            // 
            this.tlpAgregarCC.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpAgregarCC.ColumnCount = 2;
            this.tlpAgregarCC.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpAgregarCC.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpAgregarCC.Controls.Add(this.btnAgregarConf, 0, 0);
            this.tlpAgregarCC.Controls.Add(this.btnAgregarCanc, 1, 0);
            this.tlpAgregarCC.Location = new System.Drawing.Point(0, 54);
            this.tlpAgregarCC.Margin = new System.Windows.Forms.Padding(0, 3, 0, 0);
            this.tlpAgregarCC.Name = "tlpAgregarCC";
            this.tlpAgregarCC.RowCount = 1;
            this.tlpAgregarCC.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpAgregarCC.Size = new System.Drawing.Size(760, 31);
            this.tlpAgregarCC.TabIndex = 6;
            // 
            // btnAgregarConf
            // 
            this.btnAgregarConf.BackColor = System.Drawing.Color.ForestGreen;
            this.btnAgregarConf.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAgregarConf.FlatAppearance.BorderSize = 0;
            this.btnAgregarConf.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregarConf.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnAgregarConf.Font = new System.Drawing.Font("Bahnschrift SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgregarConf.ForeColor = System.Drawing.SystemColors.Control;
            this.btnAgregarConf.IconChar = FontAwesome.Sharp.IconChar.Check;
            this.btnAgregarConf.IconColor = System.Drawing.Color.White;
            this.btnAgregarConf.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnAgregarConf.IconSize = 20;
            this.btnAgregarConf.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAgregarConf.Location = new System.Drawing.Point(0, 0);
            this.btnAgregarConf.Margin = new System.Windows.Forms.Padding(0);
            this.btnAgregarConf.Name = "btnAgregarConf";
            this.btnAgregarConf.Rotation = 0D;
            this.btnAgregarConf.Size = new System.Drawing.Size(380, 31);
            this.btnAgregarConf.TabIndex = 5;
            this.btnAgregarConf.Text = "CONFIRMAR";
            this.btnAgregarConf.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAgregarConf.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAgregarConf.UseVisualStyleBackColor = false;
            this.btnAgregarConf.Click += new System.EventHandler(this.btnAgregarConf_Click);
            // 
            // btnAgregarCanc
            // 
            this.btnAgregarCanc.BackColor = System.Drawing.Color.DarkRed;
            this.btnAgregarCanc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAgregarCanc.FlatAppearance.BorderSize = 0;
            this.btnAgregarCanc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregarCanc.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnAgregarCanc.Font = new System.Drawing.Font("Bahnschrift SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgregarCanc.ForeColor = System.Drawing.SystemColors.Control;
            this.btnAgregarCanc.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.btnAgregarCanc.IconColor = System.Drawing.Color.White;
            this.btnAgregarCanc.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnAgregarCanc.IconSize = 20;
            this.btnAgregarCanc.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAgregarCanc.Location = new System.Drawing.Point(380, 0);
            this.btnAgregarCanc.Margin = new System.Windows.Forms.Padding(0);
            this.btnAgregarCanc.Name = "btnAgregarCanc";
            this.btnAgregarCanc.Rotation = 0D;
            this.btnAgregarCanc.Size = new System.Drawing.Size(380, 31);
            this.btnAgregarCanc.TabIndex = 5;
            this.btnAgregarCanc.Text = "CANCELAR";
            this.btnAgregarCanc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAgregarCanc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAgregarCanc.UseVisualStyleBackColor = false;
            this.btnAgregarCanc.Click += new System.EventHandler(this.Cancelar_Click);
            // 
            // lblAgColor
            // 
            this.lblAgColor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblAgColor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.lblAgColor.Font = new System.Drawing.Font("Bahnschrift SemiLight", 9.75F);
            this.lblAgColor.ForeColor = System.Drawing.Color.Gray;
            this.lblAgColor.Location = new System.Drawing.Point(582, -1);
            this.lblAgColor.Margin = new System.Windows.Forms.Padding(0);
            this.lblAgColor.Name = "lblAgColor";
            this.lblAgColor.Size = new System.Drawing.Size(178, 32);
            this.lblAgColor.TabIndex = 4;
            this.lblAgColor.Text = "COLOR";
            this.lblAgColor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtAgregar
            // 
            this.txtAgregar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAgregar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAgregar.Location = new System.Drawing.Point(0, 31);
            this.txtAgregar.Margin = new System.Windows.Forms.Padding(0);
            this.txtAgregar.MinimumSize = new System.Drawing.Size(2, 20);
            this.txtAgregar.Name = "txtAgregar";
            this.txtAgregar.Size = new System.Drawing.Size(582, 20);
            this.txtAgregar.TabIndex = 3;
            // 
            // lblAgNombre
            // 
            this.lblAgNombre.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblAgNombre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.lblAgNombre.Font = new System.Drawing.Font("Bahnschrift SemiLight", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAgNombre.ForeColor = System.Drawing.Color.Gray;
            this.lblAgNombre.Location = new System.Drawing.Point(0, 0);
            this.lblAgNombre.Margin = new System.Windows.Forms.Padding(0);
            this.lblAgNombre.Name = "lblAgNombre";
            this.lblAgNombre.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.lblAgNombre.Size = new System.Drawing.Size(582, 32);
            this.lblAgNombre.TabIndex = 0;
            this.lblAgNombre.Text = "NOMBRE DE MATERIA";
            this.lblAgNombre.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnAgregarColor
            // 
            this.btnAgregarColor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAgregarColor.BackColor = System.Drawing.Color.Gray;
            this.btnAgregarColor.FlatAppearance.BorderSize = 0;
            this.btnAgregarColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregarColor.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnAgregarColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btnAgregarColor.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnAgregarColor.IconColor = System.Drawing.Color.Black;
            this.btnAgregarColor.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnAgregarColor.IconSize = 48;
            this.btnAgregarColor.Location = new System.Drawing.Point(582, 31);
            this.btnAgregarColor.Margin = new System.Windows.Forms.Padding(0);
            this.btnAgregarColor.Name = "btnAgregarColor";
            this.btnAgregarColor.Rotation = 0D;
            this.btnAgregarColor.Size = new System.Drawing.Size(178, 20);
            this.btnAgregarColor.TabIndex = 1;
            this.btnAgregarColor.Text = "COLOR";
            this.btnAgregarColor.UseVisualStyleBackColor = false;
            this.btnAgregarColor.Click += new System.EventHandler(this.btnAgregarColor_Click);
            // 
            // pnlEliminar
            // 
            this.pnlEliminar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlEliminar.Controls.Add(this.tableLayoutPanel2);
            this.pnlEliminar.Controls.Add(this.txtEliminar);
            this.pnlEliminar.Controls.Add(this.lblElNombre);
            this.pnlEliminar.Location = new System.Drawing.Point(0, 279);
            this.pnlEliminar.Margin = new System.Windows.Forms.Padding(0);
            this.pnlEliminar.Name = "pnlEliminar";
            this.pnlEliminar.Size = new System.Drawing.Size(760, 86);
            this.pnlEliminar.TabIndex = 4;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.btnEliminarConf, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.btnEliminarCanc, 1, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 54);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(760, 31);
            this.tableLayoutPanel2.TabIndex = 6;
            // 
            // btnEliminarConf
            // 
            this.btnEliminarConf.BackColor = System.Drawing.Color.ForestGreen;
            this.btnEliminarConf.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEliminarConf.FlatAppearance.BorderSize = 0;
            this.btnEliminarConf.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEliminarConf.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnEliminarConf.Font = new System.Drawing.Font("Bahnschrift SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminarConf.ForeColor = System.Drawing.SystemColors.Control;
            this.btnEliminarConf.IconChar = FontAwesome.Sharp.IconChar.Check;
            this.btnEliminarConf.IconColor = System.Drawing.Color.White;
            this.btnEliminarConf.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnEliminarConf.IconSize = 20;
            this.btnEliminarConf.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEliminarConf.Location = new System.Drawing.Point(0, 0);
            this.btnEliminarConf.Margin = new System.Windows.Forms.Padding(0);
            this.btnEliminarConf.Name = "btnEliminarConf";
            this.btnEliminarConf.Rotation = 0D;
            this.btnEliminarConf.Size = new System.Drawing.Size(380, 31);
            this.btnEliminarConf.TabIndex = 5;
            this.btnEliminarConf.Text = "CONFIRMAR";
            this.btnEliminarConf.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEliminarConf.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnEliminarConf.UseVisualStyleBackColor = false;
            this.btnEliminarConf.Click += new System.EventHandler(this.btnEliminarConf_Click);
            // 
            // btnEliminarCanc
            // 
            this.btnEliminarCanc.BackColor = System.Drawing.Color.DarkRed;
            this.btnEliminarCanc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEliminarCanc.FlatAppearance.BorderSize = 0;
            this.btnEliminarCanc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEliminarCanc.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnEliminarCanc.Font = new System.Drawing.Font("Bahnschrift SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminarCanc.ForeColor = System.Drawing.SystemColors.Control;
            this.btnEliminarCanc.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.btnEliminarCanc.IconColor = System.Drawing.Color.White;
            this.btnEliminarCanc.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnEliminarCanc.IconSize = 20;
            this.btnEliminarCanc.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEliminarCanc.Location = new System.Drawing.Point(380, 0);
            this.btnEliminarCanc.Margin = new System.Windows.Forms.Padding(0);
            this.btnEliminarCanc.Name = "btnEliminarCanc";
            this.btnEliminarCanc.Rotation = 0D;
            this.btnEliminarCanc.Size = new System.Drawing.Size(380, 31);
            this.btnEliminarCanc.TabIndex = 5;
            this.btnEliminarCanc.Text = "CANCELAR";
            this.btnEliminarCanc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEliminarCanc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnEliminarCanc.UseVisualStyleBackColor = false;
            this.btnEliminarCanc.Click += new System.EventHandler(this.Cancelar_Click);
            // 
            // txtEliminar
            // 
            this.txtEliminar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEliminar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEliminar.Location = new System.Drawing.Point(0, 31);
            this.txtEliminar.Margin = new System.Windows.Forms.Padding(0);
            this.txtEliminar.MinimumSize = new System.Drawing.Size(2, 20);
            this.txtEliminar.Name = "txtEliminar";
            this.txtEliminar.Size = new System.Drawing.Size(760, 20);
            this.txtEliminar.TabIndex = 3;
            // 
            // lblElNombre
            // 
            this.lblElNombre.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblElNombre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.lblElNombre.Font = new System.Drawing.Font("Bahnschrift SemiLight", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblElNombre.ForeColor = System.Drawing.Color.Gray;
            this.lblElNombre.Location = new System.Drawing.Point(0, 0);
            this.lblElNombre.Margin = new System.Windows.Forms.Padding(0);
            this.lblElNombre.Name = "lblElNombre";
            this.lblElNombre.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.lblElNombre.Size = new System.Drawing.Size(760, 32);
            this.lblElNombre.TabIndex = 0;
            this.lblElNombre.Text = "NOMBRE DE MATERIA";
            this.lblElNombre.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pnlEditar
            // 
            this.pnlEditar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlEditar.Controls.Add(this.tlpEditar);
            this.pnlEditar.Controls.Add(this.tlpEditarCC);
            this.pnlEditar.Controls.Add(this.lblEdColor);
            this.pnlEditar.Controls.Add(this.btnEditarColor);
            this.pnlEditar.Location = new System.Drawing.Point(0, 193);
            this.pnlEditar.Margin = new System.Windows.Forms.Padding(0);
            this.pnlEditar.Name = "pnlEditar";
            this.pnlEditar.Size = new System.Drawing.Size(760, 86);
            this.pnlEditar.TabIndex = 4;
            // 
            // tlpEditar
            // 
            this.tlpEditar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpEditar.ColumnCount = 2;
            this.tlpEditar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpEditar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpEditar.Controls.Add(this.pnlEdMateria, 0, 0);
            this.tlpEditar.Controls.Add(this.pnlEdNuevo, 1, 0);
            this.tlpEditar.Location = new System.Drawing.Point(0, 0);
            this.tlpEditar.Margin = new System.Windows.Forms.Padding(0);
            this.tlpEditar.Name = "tlpEditar";
            this.tlpEditar.RowCount = 1;
            this.tlpEditar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpEditar.Size = new System.Drawing.Size(582, 52);
            this.tlpEditar.TabIndex = 5;
            // 
            // pnlEdMateria
            // 
            this.pnlEdMateria.Controls.Add(this.lblEdMateria);
            this.pnlEdMateria.Controls.Add(this.txtEdMateria);
            this.pnlEdMateria.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlEdMateria.Location = new System.Drawing.Point(0, 0);
            this.pnlEdMateria.Margin = new System.Windows.Forms.Padding(0, 0, 1, 0);
            this.pnlEdMateria.Name = "pnlEdMateria";
            this.pnlEdMateria.Size = new System.Drawing.Size(290, 52);
            this.pnlEdMateria.TabIndex = 5;
            // 
            // lblEdMateria
            // 
            this.lblEdMateria.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblEdMateria.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.lblEdMateria.Font = new System.Drawing.Font("Bahnschrift SemiLight", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEdMateria.ForeColor = System.Drawing.Color.Gray;
            this.lblEdMateria.Location = new System.Drawing.Point(0, 0);
            this.lblEdMateria.Margin = new System.Windows.Forms.Padding(0);
            this.lblEdMateria.Name = "lblEdMateria";
            this.lblEdMateria.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.lblEdMateria.Size = new System.Drawing.Size(290, 32);
            this.lblEdMateria.TabIndex = 0;
            this.lblEdMateria.Text = "MATERIA A EDITAR";
            this.lblEdMateria.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtEdMateria
            // 
            this.txtEdMateria.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEdMateria.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEdMateria.Location = new System.Drawing.Point(0, 31);
            this.txtEdMateria.Margin = new System.Windows.Forms.Padding(0);
            this.txtEdMateria.MinimumSize = new System.Drawing.Size(2, 20);
            this.txtEdMateria.Name = "txtEdMateria";
            this.txtEdMateria.Size = new System.Drawing.Size(290, 20);
            this.txtEdMateria.TabIndex = 3;
            // 
            // pnlEdNuevo
            // 
            this.pnlEdNuevo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlEdNuevo.Controls.Add(this.lblEdNuevo);
            this.pnlEdNuevo.Controls.Add(this.txtEdNuevo);
            this.pnlEdNuevo.Location = new System.Drawing.Point(292, 0);
            this.pnlEdNuevo.Margin = new System.Windows.Forms.Padding(1, 0, 0, 0);
            this.pnlEdNuevo.Name = "pnlEdNuevo";
            this.pnlEdNuevo.Size = new System.Drawing.Size(290, 52);
            this.pnlEdNuevo.TabIndex = 5;
            // 
            // lblEdNuevo
            // 
            this.lblEdNuevo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblEdNuevo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.lblEdNuevo.Font = new System.Drawing.Font("Bahnschrift SemiLight", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEdNuevo.ForeColor = System.Drawing.Color.Gray;
            this.lblEdNuevo.Location = new System.Drawing.Point(0, 0);
            this.lblEdNuevo.Margin = new System.Windows.Forms.Padding(0);
            this.lblEdNuevo.Name = "lblEdNuevo";
            this.lblEdNuevo.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.lblEdNuevo.Size = new System.Drawing.Size(290, 32);
            this.lblEdNuevo.TabIndex = 0;
            this.lblEdNuevo.Text = "NUEVO NOMBRE";
            this.lblEdNuevo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtEdNuevo
            // 
            this.txtEdNuevo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEdNuevo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEdNuevo.Location = new System.Drawing.Point(0, 31);
            this.txtEdNuevo.Margin = new System.Windows.Forms.Padding(0);
            this.txtEdNuevo.MinimumSize = new System.Drawing.Size(2, 20);
            this.txtEdNuevo.Name = "txtEdNuevo";
            this.txtEdNuevo.Size = new System.Drawing.Size(290, 20);
            this.txtEdNuevo.TabIndex = 3;
            // 
            // tlpEditarCC
            // 
            this.tlpEditarCC.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpEditarCC.ColumnCount = 2;
            this.tlpEditarCC.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpEditarCC.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpEditarCC.Controls.Add(this.btnEditarConf, 0, 0);
            this.tlpEditarCC.Controls.Add(this.btnEditarCanc, 1, 0);
            this.tlpEditarCC.Location = new System.Drawing.Point(0, 54);
            this.tlpEditarCC.Margin = new System.Windows.Forms.Padding(0, 3, 0, 0);
            this.tlpEditarCC.Name = "tlpEditarCC";
            this.tlpEditarCC.RowCount = 1;
            this.tlpEditarCC.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpEditarCC.Size = new System.Drawing.Size(760, 31);
            this.tlpEditarCC.TabIndex = 6;
            // 
            // btnEditarConf
            // 
            this.btnEditarConf.BackColor = System.Drawing.Color.ForestGreen;
            this.btnEditarConf.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEditarConf.FlatAppearance.BorderSize = 0;
            this.btnEditarConf.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEditarConf.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnEditarConf.Font = new System.Drawing.Font("Bahnschrift SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditarConf.ForeColor = System.Drawing.SystemColors.Control;
            this.btnEditarConf.IconChar = FontAwesome.Sharp.IconChar.Check;
            this.btnEditarConf.IconColor = System.Drawing.Color.White;
            this.btnEditarConf.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnEditarConf.IconSize = 20;
            this.btnEditarConf.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEditarConf.Location = new System.Drawing.Point(0, 0);
            this.btnEditarConf.Margin = new System.Windows.Forms.Padding(0);
            this.btnEditarConf.Name = "btnEditarConf";
            this.btnEditarConf.Rotation = 0D;
            this.btnEditarConf.Size = new System.Drawing.Size(380, 31);
            this.btnEditarConf.TabIndex = 5;
            this.btnEditarConf.Text = "CONFIRMAR";
            this.btnEditarConf.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEditarConf.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnEditarConf.UseVisualStyleBackColor = false;
            this.btnEditarConf.Click += new System.EventHandler(this.btnEditarConf_Click);
            // 
            // btnEditarCanc
            // 
            this.btnEditarCanc.BackColor = System.Drawing.Color.DarkRed;
            this.btnEditarCanc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEditarCanc.FlatAppearance.BorderSize = 0;
            this.btnEditarCanc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEditarCanc.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnEditarCanc.Font = new System.Drawing.Font("Bahnschrift SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditarCanc.ForeColor = System.Drawing.SystemColors.Control;
            this.btnEditarCanc.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.btnEditarCanc.IconColor = System.Drawing.Color.White;
            this.btnEditarCanc.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnEditarCanc.IconSize = 20;
            this.btnEditarCanc.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEditarCanc.Location = new System.Drawing.Point(380, 0);
            this.btnEditarCanc.Margin = new System.Windows.Forms.Padding(0);
            this.btnEditarCanc.Name = "btnEditarCanc";
            this.btnEditarCanc.Rotation = 0D;
            this.btnEditarCanc.Size = new System.Drawing.Size(380, 31);
            this.btnEditarCanc.TabIndex = 5;
            this.btnEditarCanc.Text = "CANCELAR";
            this.btnEditarCanc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEditarCanc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnEditarCanc.UseVisualStyleBackColor = false;
            this.btnEditarCanc.Click += new System.EventHandler(this.Cancelar_Click);
            // 
            // lblEdColor
            // 
            this.lblEdColor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblEdColor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.lblEdColor.Font = new System.Drawing.Font("Bahnschrift SemiLight", 9.75F);
            this.lblEdColor.ForeColor = System.Drawing.Color.Gray;
            this.lblEdColor.Location = new System.Drawing.Point(582, 0);
            this.lblEdColor.Margin = new System.Windows.Forms.Padding(0);
            this.lblEdColor.Name = "lblEdColor";
            this.lblEdColor.Size = new System.Drawing.Size(178, 32);
            this.lblEdColor.TabIndex = 4;
            this.lblEdColor.Text = "NUEVO COLOR";
            this.lblEdColor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnEditarColor
            // 
            this.btnEditarColor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEditarColor.BackColor = System.Drawing.Color.Gray;
            this.btnEditarColor.FlatAppearance.BorderSize = 0;
            this.btnEditarColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEditarColor.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnEditarColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btnEditarColor.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnEditarColor.IconColor = System.Drawing.Color.Black;
            this.btnEditarColor.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnEditarColor.IconSize = 48;
            this.btnEditarColor.Location = new System.Drawing.Point(582, 32);
            this.btnEditarColor.Margin = new System.Windows.Forms.Padding(0);
            this.btnEditarColor.Name = "btnEditarColor";
            this.btnEditarColor.Rotation = 0D;
            this.btnEditarColor.Size = new System.Drawing.Size(178, 19);
            this.btnEditarColor.TabIndex = 1;
            this.btnEditarColor.Text = "COLOR";
            this.btnEditarColor.UseVisualStyleBackColor = false;
            this.btnEditarColor.Click += new System.EventHandler(this.btnEditarColor_Click);
            // 
            // lblWarning
            // 
            this.lblWarning.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblWarning.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.lblWarning.Font = new System.Drawing.Font("Bahnschrift SemiLight", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWarning.ForeColor = System.Drawing.Color.Red;
            this.lblWarning.Location = new System.Drawing.Point(0, 128);
            this.lblWarning.Margin = new System.Windows.Forms.Padding(0);
            this.lblWarning.Name = "lblWarning";
            this.lblWarning.Size = new System.Drawing.Size(760, 26);
            this.lblWarning.TabIndex = 0;
            this.lblWarning.Text = "[YA EXISTE UNA MATERIA CON ESE NOMBRE. INGRESA OTRO]";
            this.lblWarning.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tlpBotonesMaterias
            // 
            this.tlpBotonesMaterias.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpBotonesMaterias.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.tlpBotonesMaterias.ColumnCount = 3;
            this.tlpBotonesMaterias.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tlpBotonesMaterias.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tlpBotonesMaterias.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tlpBotonesMaterias.Controls.Add(this.btnAgregar, 0, 0);
            this.tlpBotonesMaterias.Controls.Add(this.btnEliminar, 2, 0);
            this.tlpBotonesMaterias.Controls.Add(this.btnEditar, 1, 0);
            this.tlpBotonesMaterias.Location = new System.Drawing.Point(0, 0);
            this.tlpBotonesMaterias.Margin = new System.Windows.Forms.Padding(0);
            this.tlpBotonesMaterias.Name = "tlpBotonesMaterias";
            this.tlpBotonesMaterias.RowCount = 1;
            this.tlpBotonesMaterias.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpBotonesMaterias.Size = new System.Drawing.Size(760, 42);
            this.tlpBotonesMaterias.TabIndex = 3;
            // 
            // btnAgregar
            // 
            this.btnAgregar.BackColor = System.Drawing.Color.Gray;
            this.btnAgregar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAgregar.FlatAppearance.BorderSize = 0;
            this.btnAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregar.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnAgregar.Font = new System.Drawing.Font("Bahnschrift SemiLight", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgregar.IconChar = FontAwesome.Sharp.IconChar.Plus;
            this.btnAgregar.IconColor = System.Drawing.Color.Black;
            this.btnAgregar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnAgregar.IconSize = 30;
            this.btnAgregar.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAgregar.Location = new System.Drawing.Point(0, 0);
            this.btnAgregar.Margin = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Rotation = 0D;
            this.btnAgregar.Size = new System.Drawing.Size(251, 42);
            this.btnAgregar.TabIndex = 2;
            this.btnAgregar.Text = "AGREGAR";
            this.btnAgregar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAgregar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAgregar.UseVisualStyleBackColor = false;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.BackColor = System.Drawing.Color.Gray;
            this.btnEliminar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEliminar.FlatAppearance.BorderSize = 0;
            this.btnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEliminar.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnEliminar.Font = new System.Drawing.Font("Bahnschrift SemiLight", 14F);
            this.btnEliminar.IconChar = FontAwesome.Sharp.IconChar.Eraser;
            this.btnEliminar.IconColor = System.Drawing.Color.Black;
            this.btnEliminar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnEliminar.IconSize = 30;
            this.btnEliminar.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEliminar.Location = new System.Drawing.Point(506, 0);
            this.btnEliminar.Margin = new System.Windows.Forms.Padding(0);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Rotation = 0D;
            this.btnEliminar.Size = new System.Drawing.Size(254, 42);
            this.btnEliminar.TabIndex = 2;
            this.btnEliminar.Text = "ELIMINAR";
            this.btnEliminar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEliminar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnEliminar.UseVisualStyleBackColor = false;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // btnEditar
            // 
            this.btnEditar.BackColor = System.Drawing.Color.Gray;
            this.btnEditar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEditar.FlatAppearance.BorderSize = 0;
            this.btnEditar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEditar.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnEditar.Font = new System.Drawing.Font("Bahnschrift SemiLight", 14F);
            this.btnEditar.IconChar = FontAwesome.Sharp.IconChar.Edit;
            this.btnEditar.IconColor = System.Drawing.Color.Black;
            this.btnEditar.IconFont = FontAwesome.Sharp.IconFont.Solid;
            this.btnEditar.IconSize = 30;
            this.btnEditar.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEditar.Location = new System.Drawing.Point(253, 0);
            this.btnEditar.Margin = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Rotation = 0D;
            this.btnEditar.Size = new System.Drawing.Size(251, 42);
            this.btnEditar.TabIndex = 2;
            this.btnEditar.Text = "EDITAR";
            this.btnEditar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEditar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnEditar.UseVisualStyleBackColor = false;
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // pnlMaterias
            // 
            this.pnlMaterias.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlMaterias.AutoScroll = true;
            this.pnlMaterias.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.pnlMaterias.Location = new System.Drawing.Point(20, 75);
            this.pnlMaterias.Margin = new System.Windows.Forms.Padding(0);
            this.pnlMaterias.Name = "pnlMaterias";
            this.pnlMaterias.Size = new System.Drawing.Size(760, 355);
            this.pnlMaterias.TabIndex = 2;
            // 
            // Materias
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnlBotonesMaterias);
            this.Controls.Add(this.panelTEMPORAL);
            this.Controls.Add(this.pnlMaterias);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Materias";
            this.Text = "Materias";
            this.Load += new System.EventHandler(this.Materias_Load);
            this.pnlBotonesMaterias.ResumeLayout(false);
            this.pnlAgregar.ResumeLayout(false);
            this.pnlAgregar.PerformLayout();
            this.tlpAgregarCC.ResumeLayout(false);
            this.pnlEliminar.ResumeLayout(false);
            this.pnlEliminar.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.pnlEditar.ResumeLayout(false);
            this.tlpEditar.ResumeLayout(false);
            this.pnlEdMateria.ResumeLayout(false);
            this.pnlEdMateria.PerformLayout();
            this.pnlEdNuevo.ResumeLayout(false);
            this.pnlEdNuevo.PerformLayout();
            this.tlpEditarCC.ResumeLayout(false);
            this.tlpBotonesMaterias.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelTEMPORAL;
        private System.Windows.Forms.Panel pnlBotonesMaterias;
        private FontAwesome.Sharp.IconButton btnAgregar;
        private System.Windows.Forms.TableLayoutPanel tlpBotonesMaterias;
        private FontAwesome.Sharp.IconButton btnEliminar;
        private FontAwesome.Sharp.IconButton btnEditar;
        private FontAwesome.Sharp.IconButton btnAgregarConf;
        private System.Windows.Forms.Panel pnlAgregar;
        private System.Windows.Forms.Label lblAgColor;
        private System.Windows.Forms.TextBox txtAgregar;
        private FontAwesome.Sharp.IconButton btnAgregarColor;
        private System.Windows.Forms.Label lblAgNombre;
        private System.Windows.Forms.TableLayoutPanel tlpAgregarCC;
        private FontAwesome.Sharp.IconButton btnAgregarCanc;
        private System.Windows.Forms.Panel pnlEditar;
        private System.Windows.Forms.TableLayoutPanel tlpEditarCC;
        private FontAwesome.Sharp.IconButton btnEditarConf;
        private FontAwesome.Sharp.IconButton btnEditarCanc;
        private System.Windows.Forms.Label lblEdColor;
        private System.Windows.Forms.TextBox txtEdMateria;
        private System.Windows.Forms.TextBox txtEdNuevo;
        private FontAwesome.Sharp.IconButton btnEditarColor;
        private System.Windows.Forms.Label lblEdMateria;
        private System.Windows.Forms.Label lblEdNuevo;
        private System.Windows.Forms.Panel pnlEliminar;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private FontAwesome.Sharp.IconButton btnEliminarConf;
        private FontAwesome.Sharp.IconButton btnEliminarCanc;
        private System.Windows.Forms.TextBox txtEliminar;
        private System.Windows.Forms.Label lblElNombre;
        private System.Windows.Forms.TableLayoutPanel tlpEditar;
        private System.Windows.Forms.Panel pnlEdMateria;
        private System.Windows.Forms.Panel pnlEdNuevo;
        private System.Windows.Forms.Panel pnlMaterias;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Label lblWarning;
    }
}