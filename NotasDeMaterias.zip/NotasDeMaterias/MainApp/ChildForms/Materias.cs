﻿using FontAwesome.Sharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MainApp.ChildForms
{
    public partial class Materias : Form
    {
        ControlBotones Botones = new ControlBotones();

        public Materias()
        {
            InitializeComponent();
        }

        private void Materias_Load(object sender, EventArgs e)
        {
            pnlBotonesMaterias.Height = 42;
            pnlAgregar.Location = new System.Drawing.Point(0, 42);
            pnlEditar.Location = new System.Drawing.Point(0, 42);
            pnlEliminar.Location = new System.Drawing.Point(0, 42);
            CargarBotones();
        }
       
        //Animaciones de menú
        private void AbrirMenu() {
            for(int i = 0; pnlBotonesMaterias.Height < 128; i++)
            {
                pnlBotonesMaterias.Height = pnlBotonesMaterias.Height + 5;
                if (pnlBotonesMaterias.Height > 118)
                {
                    pnlBotonesMaterias.Height = 128;
                }
                this.Refresh();
            }
        }
        private void CerrarMenu()
        {
            for (int i = 0; pnlBotonesMaterias.Height > 44; i++)
            {
                pnlBotonesMaterias.Height = pnlBotonesMaterias.Height - 10;
                this.Refresh();
            }
            pnlAgregar.Visible = false;
            pnlEditar.Visible = false;
            pnlEliminar.Visible = false;
            lblAgColor.Text = "COLOR";
            btnAgregarColor.BackColor = Color.Gray;
            btnAgregarColor.Text = "ELEGIR COLOR";
            lblEdColor.Text = "COLOR";
            btnEditarColor.BackColor = Color.Gray;
            btnEditarColor.Text = "ELEGIR COLOR";
        }

        //Botones de menú
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            CerrarMenu();
            pnlAgregar.Visible = true;
            AbrirMenu();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            CerrarMenu();
            pnlEditar.Visible = true;
            AbrirMenu();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            CerrarMenu();
            pnlEliminar.Visible = true;
            AbrirMenu();
        }

        //Botones "Color"
        private void btnAgregarColor_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                btnAgregarColor.BackColor = colorDialog1.Color;
                btnAgregarColor.Text = "";
            }
        }

        private void btnEditarColor_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                btnEditarColor.BackColor = colorDialog1.Color;
                btnEditarColor.Text = "";
            }
        }

        //Cancelar menú (Handler en común)
        private void Cancelar_Click(object sender, EventArgs e)
        {
            CerrarMenu();
        }

        //Confirmar menú
        private void btnAgregarConf_Click(object sender, EventArgs e)
        {
            if (txtAgregar.Text != "" && Botones.listMat.NoCoincide(txtAgregar.Text.ToLower()) == true)
            {
                Button Temp = Botones.CrearBoton(
                    txtAgregar.Text.ToLower(),
                    btnAgregarColor.BackColor.A,
                    btnAgregarColor.BackColor.R,
                    btnAgregarColor.BackColor.G,
                    btnAgregarColor.BackColor.B);

                MostrarBoton(Temp);

                Botones.listMat.Guardar(
                    txtAgregar.Text.ToLower(),
                    btnAgregarColor.BackColor.A,
                    btnAgregarColor.BackColor.R,
                    btnAgregarColor.BackColor.G,
                    btnAgregarColor.BackColor.B);

                CerrarMenu();
            }
            else
            {
                if (txtAgregar.Text == "")
                {
                    lblWarning.Text = "[DEBES INGRESAR UN NOMBRE PARA LA MATERIA]";
                    pnlBotonesMaterias.Height = 154;
                }
                else
                {
                    lblWarning.Text = "[YA EXISTE UNA MATERIA CON ESE NOMBRE. INGRESA OTRO]";
                    pnlBotonesMaterias.Height = 154;
                }
            }
            
        }

        private void btnEditarConf_Click(object sender, EventArgs e)
        {
            if (txtEdMateria.Text != "")
            {
                if (txtEdNuevo.Text != "")
                {
                    bool cambioExitoso = Botones.listMat.Editar(
                        txtEdMateria.Text.ToLower(),
                        txtEdNuevo.Text.ToLower(),
                        Convert.ToInt32(btnEditarColor.BackColor.A),
                        Convert.ToInt32(btnEditarColor.BackColor.R),
                        Convert.ToInt32(btnEditarColor.BackColor.G),
                        Convert.ToInt32(btnEditarColor.BackColor.B));

                    if (cambioExitoso == true)
                    {
                        pnlMaterias.Controls.Clear();
                        CargarBotones();
                        CerrarMenu();
                    }
                    else
                    {
                        lblWarning.Text = "[No se encontró materia registrada con ese nombre. Intenta nuevamente]";
                        pnlBotonesMaterias.Height = 154;
                    }
                }
                else
                {
                    lblWarning.Text = "[Debes darle un nuevo nombre a la materia elegida]";
                    pnlBotonesMaterias.Height = 154;
                }
                
            }
            else
            {
                lblWarning.Text = "[Debes indicar el nombre de la materia a editar]";
                pnlBotonesMaterias.Height = 154;
            }
        }

        private void btnEliminarConf_Click(object sender, EventArgs e)
        {
            CerrarMenu();
        }

        //Metodos de botones de materia
        public void AbrirMateria(object sender, EventArgs e) 
        {

        }

        public void CargarBotones()
        {
            Botones.ReiniciarPosicion();
            for (int i = 0; i < Botones.listMat.Lista.Rows.Count; i++)
            {
                Button Temp = Botones.CrearBoton(
                    Botones.listMat.Lista.Rows[i]["Nombre"].ToString(),
                    Convert.ToInt32(Botones.listMat.Lista.Rows[i]["A"]),
                    Convert.ToInt32(Botones.listMat.Lista.Rows[i]["R"]),
                    Convert.ToInt32(Botones.listMat.Lista.Rows[i]["G"]),
                    Convert.ToInt32(Botones.listMat.Lista.Rows[i]["B"]));
                MostrarBoton(Temp);
            }
        }

        public void MostrarBoton(Button boton) 
        {
            boton.Click += new EventHandler(AbrirMateria);
            pnlMaterias.Controls.Add(boton);
        }
    }
}
