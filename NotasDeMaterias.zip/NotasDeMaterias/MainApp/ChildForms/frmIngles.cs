﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MainApp
{
    public partial class frmIngles : Form
    {
        DataTable Ingles = new DataTable();
        string xmlFile = "Ingles.xml";

        public frmIngles()
        {
            InitializeComponent();
            Ingles.TableName = "Ingles";
            Ingles.Columns.Add("DETALLE", typeof(string));
            Ingles.Columns.Add("FECHA LIMITE", typeof(DateTime));

            if (!System.IO.File.Exists(xmlFile))
            {
                Ingles.WriteXml(xmlFile);
            }
            Ingles.ReadXml(xmlFile);
        }

        private void frmProgramacion_Load(object sender, EventArgs e)
        {           
            dgvIngles.DataSource = Ingles;
            dgvIngles.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvIngles.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            dgvIngles.Columns[1].Width = 135;
        }

        private void frmProgramacion_FormClosing(object sender, FormClosingEventArgs e)
        { 
            Ingles.WriteXml(xmlFile);
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Ingles.Rows.Add();
            Ingles.Rows[Ingles.Rows.Count - 1]["DETALLE"] = txtDetalle.Text;
            Ingles.Rows[Ingles.Rows.Count - 1]["FECHA LIMITE"] = dtpFecha.Value;
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (!(dgvIngles.SelectedRows.Count == 0))
            {
                Ingles.Rows.RemoveAt(dgvIngles.SelectedRows[0].Index);
            }
        }
    }
}
