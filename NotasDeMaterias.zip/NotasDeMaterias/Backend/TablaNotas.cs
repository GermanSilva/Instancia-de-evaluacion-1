﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Backend
{
    class TablaNotas
    {
        public DataTable dtNotas = new DataTable();

        public TablaNotas()
        {
            dtNotas.TableName = "Notas";
            dtNotas.Columns.Add("Detalles", typeof(string));
            dtNotas.Columns.Add("Fecha", typeof(string));
        }


        public DataTable CargarTabla(string nombre) 
        {
            if (!System.IO.File.Exists(nombre + ".xml"))
            {
                dtNotas.WriteXml(nombre + ".xml");
            }
            dtNotas.ReadXml(nombre + ".xml");
            return dtNotas;
        }

        public void GuardarNota(string detalle, string fecha, string nombre) 
        {
            dtNotas.Rows.Add();
            dtNotas.Rows[dtNotas.Rows.Count - 1]["Detalles"] = detalle;
            dtNotas.Rows[dtNotas.Rows.Count - 1]["Fecha"] = fecha;
            dtNotas.WriteXml(nombre + ".xml");
        }

        public void EliminarNota(int indice, string nombre) 
        {
            dtNotas.Rows.RemoveAt(indice);
            dtNotas.WriteXml(nombre + ".xml");
        }
    }
}
